var latest_stable_build   = 47;
var latest_stable_version = '1.0';
var latest_stable_url     = 'http://www.net2ftp.com/download/net2ftp_v1.0.zip';

var latest_beta_build     = 47;
var latest_beta_version   = '1.0';
var latest_beta_url       = 'http://www.net2ftp.com/download/net2ftp_v1.0.zip';
