<?php
$myCode = @$_REQUEST["code"];
print $myCode ;
?>
