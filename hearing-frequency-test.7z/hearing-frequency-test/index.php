<!DOCTYPE html>
<html lang="en">
<head>
<LINK REL="SHORTCUT ICON" href="../avatar brigante.jpg">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=windows-1251">
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<meta name="description" content="Hearing Frequency Test">
<meta name="keywords" content="hearing frequency, hearing frequency test, test your hearing, hearing test, online hearing test">
<title>Free Online Hearing Test</title>
<link type="text/css" rel="stylesheet" href="../css/main.css" />
</head>
<body>

<a href="../">Free Online Tools</a>

<h2>Hearing Frequency Test</h2>

The normal range for young people is 20hz to 20khz, but high frequency perception declines as we age.<br> 
Use this flash based online hearing tests to see how sharp your hearing is.<br>

<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=9,0,28,0" width="560" height="400">
        <param name="movie" value="online-hearing-test.swf" />
        <param name="quality" value="high" />
        <embed src="online-hearing-test.swf" quality="high" pluginspage="http://www.adobe.com/shockwave/download/download.cgi?P1_Prod_Version=ShockwaveFlash" type="application/x-shockwave-flash" width="560" height="400"></embed>
</object>


<p>Other hearing frequency facts:</p>

Humans can hear between 20 Hz to 20,000 Hz<br>
Dogs can hear between 40 Hz to 60,000 Hz<br>
Bats can hear between 20 Hz to 120,000 Hz<br>
Bats can hear between 1000 Hz to 90,000 Hz<br>

<?php
include '../footer.php';
?>
