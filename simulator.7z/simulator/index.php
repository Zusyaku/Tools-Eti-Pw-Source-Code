<html>
<head>
<meta charset=utf-8>
<meta charset=windows-1251>
<LINK REL="SHORTCUT ICON" HREF="eti.ico">
<title>Simple Mobile Simulator</title>
<meta name="Description" content="Mobile Simulator|Mobile Phone Emulator that enables you to test the display of your website in cell smart phones,tablets">
<meta name="Keywords" content="mobile phone emulator, test mobile website, mobile simulator, mobile emulator, emulator, mobile, phone simulator, phone emulator, tablet emulator, tablet simulator, online simulator, online mobile simulator, online mobile phone simulator, iphone emulator, мобилен емулатор, мобилен симулатор,таблет симулатор, емулатор">
<meta name="Author" content="Evgeni Toshev Ivanov - www.eti.pw" />

<script type="text/javascript" src="jquery.min.js"></script>
<script type="text/javascript" src="jquery.url.min.js"></script>
<script type="text/javascript" src="script.js"></script>
<link rel="stylesheet" href="style.css" />




</head>

<body>




<!-- AddThis Button BEGIN -->
<div class="addthis_toolbox addthis_default_style ">
<a class="addthis_button_preferred_1"></a>
<a class="addthis_button_preferred_2"></a>
<a class="addthis_button_preferred_3"></a>
<a class="addthis_button_preferred_4"></a>
<a class="addthis_button_compact"></a>
<a class="addthis_counter addthis_bubble_style"></a>
</div>
<script type="text/javascript">var addthis_config = {"data_track_addressbar":true};</script>
<script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-50b807f74e264eae"></script>
<!-- AddThis Button END -->

</div>




<div class="buttons">
<div class="button" id="to_iphone"></div>
<div class="button" id="to_iphone5"></div>
<div class="button" id="rotate"></div>
</div>
</div>

<div id="iphone" class="portrait" style="margin-top: 80px;">
  <div id="kbd"></div>
  <input id="url"></input>
  <iframe id="frame"></iframe>
</div>

<center>
<!-- hitwebcounter Code START -->
<a href="http://www.hitwebcounter.com/" target="_blank">
<img src="http://hitwebcounter.com/counter/counter.php?page=4653081&style=0010&nbdigits=5&type=ip&initCount=1" title="" Alt="" border="0" ></a>
</center>

</body>
</html>
