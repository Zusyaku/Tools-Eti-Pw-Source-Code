<!DOCTYPE html>
<html lang="en">
<head>
<LINK REL="SHORTCUT ICON" href="../avatar brigante.jpg">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=windows-1251">
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<meta name="description" content="Online Video Downloader that helps you download Instagram.com videos">
<meta name="keywords" content="instagram video downloader, instagram downloader, download instagram videos, download instagram videos online">
<title>Download Instagram Videos Online</title>
<link type="text/css" rel="stylesheet" href="../css/main.css" />
</head>
<body>

<a href="../">Free Online Tools</a>
				
<h2>Instagram Video Downloader</h2>
			
<form action="get-instagram-video.php" method="post">
<input type="text" name="url" placeholder="Video Link here">
<input class="button" value="Download" type="submit">
</form>

<?php
include '../footer.php';
?>
